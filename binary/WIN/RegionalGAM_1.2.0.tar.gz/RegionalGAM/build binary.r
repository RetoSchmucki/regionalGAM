
dir.create("C:/Users/RETOSCHM/OneDrive - Natural Environment Research Council/regionalGAM/binary/WIN",recursive=TRUE)
devtools::build("C:/Users/RETOSCHM/OneDrive - Natural Environment Research Council/regionalGAM",path="C:/Users/RETOSCHM/OneDrive - Natural Environment Research Council/regionalGAM/binary/WIN",vignette=FALSE,manual=TRUE)


dir.create("/Users/retoschmucki/CEH-OneDriveBusiness/OneDrive - Natural Environment Research Council/regionalGAM/binary/MacOS",recursive=TRUE)
devtools::build("/Users/retoschmucki/CEH-OneDriveBusiness/OneDrive - Natural Environment Research Council/regionalGAM",path="/Users/retoschmucki/CEH-OneDriveBusiness/OneDrive - Natural Environment Research Council/regionalGAM/binary/MacOS",vignette=FALSE,manual=TRUE)